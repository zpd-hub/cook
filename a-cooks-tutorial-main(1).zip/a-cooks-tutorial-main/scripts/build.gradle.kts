import org.tribot.gradle.plugin.TribotPlugin

subprojects {
    apply<TribotPlugin>()
}