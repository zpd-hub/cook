dependencies {
    implementation(project(":libraries:my-library"))
}