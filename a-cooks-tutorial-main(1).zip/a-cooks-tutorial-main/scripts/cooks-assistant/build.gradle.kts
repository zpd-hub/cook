dependencies {
    implementation(project(":libraries:my-library"))
    implementation(project(":libraries:framework"))
}